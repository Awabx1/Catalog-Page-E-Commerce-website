import './App.css';
import Cat from './component/catalog';
import Header from './component/header';


function App() {
  return (
    <div className="App">
      <Header />
      <Cat />
    </div>
  );
}

export default App;
