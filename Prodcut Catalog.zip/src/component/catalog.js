import React from "react";

export default function catalog(){
    return (
        <div className="catalog_heading">
           Top Vechiles in your area right now
           
           <div className="rangerover">
            <img src="media/refined/rr.png" alt="rangerover"></img>
            
            <div className="rrtext">
                Range Rover
                    <div className="rrinfo">
                        Price: $55,000
                        <div className="rrdesc">
                        Powerful electryfing performace, engineering to meet every challenege. Powerful electryfing performace, engineering to meet every challenege. 
                         </div>
                    </div>
                    <div className="viewbutton">
                        <button className="vbtn">Buy</button>
                    </div>
            </div>
           
           </div>

           <div className="camry">
            <img src="media/refined/camry.png" alt="camry"></img>
            
            <div className="camrytext">
                Camry
                    <div className="camryinfo">
                        Price: $55,000
                        <div className="camrydesc">
                        Powerful electryfing performace, engineering to meet every challenege. Powerful electryfing performace, engineering to meet every challenege. 
                         </div>
                    </div>
                    <div className="viewbutton">
                        <button className="vbtn">Buy</button>
                    </div>
            </div>
            
           
           </div>


           <div className="lc">
            <img src="media/refined/lc.png" alt="lc"></img>
            
            <div className="lctext">
                Land Cruiser
                    <div className="lcinfo">
                        Price: $55,000
                        <div className="lcdesc">
                        Powerful electryfing performace, engineering to meet every challenege. Powerful electryfing performace, engineering to meet every challenege. 
                         </div>
                    </div>
                    <div className="viewbutton">
                        <button className="vbtn">Buy</button>
                        
                    </div>
            </div>
            
           
           </div>


        
        </div>
    )
}