import React from "react";

export default function header(){
    return (
        <div className="header">
            <nav>
            <img src="media/logo.png" className="logo" alt="(nothing)"></img>    
            <ul class="nav-links">
                <li> <a href="(nothing)">Home</a></li>
                <li> <a href="catalog.html">Vehicles</a></li>
                <li> <a href="(nothing)">Blog</a></li>
                <li> <a href="(nothing)">Contact Us</a></li>
                <li class="signupbtn"><a href="signup.html" class="signupbtn2">Sign Up</a></li>
            </ul>
            </nav> 

            <div class="content">
                <h1>Browse the Best Vehicles</h1>
                <form>
                    <input type="text" placeholder="Enter Model Name"></input>
                    <button type="submit">Find Vehicles</button>
                </form>
            </div>
        </div>
    )
}